# AMRL source-data attachment

Scope: 265 distinct formal training runs, 53 complete five-seed condition groups, and 5,300 final evaluation episodes. All formal runs use training seeds 0–4; each seed score averages 20 deterministic-action evaluation episodes. The 42 additional exploratory deployments are separate and have uneven seed coverage.

Files:

| File | Records | Content |
|---|---:|---|
| seed_results.csv | 265 | Formal seed scores, stage timers, source and controller fingerprints |
| evaluation_episodes.csv | 5,300 | Individual episode returns and evaluation seeds |
| summary.csv | 53 | Formal five-seed means and sample SDs |
| paired_statistics.json | 41 | Paired estimates, intervals, t/sign-flip tests and primary-family Holm correction |
| plot_records.json | 265 | Scores, diagnostics, controller actions, and projected hyperparameters used by the figures |
| cartpole_ppo_amrl_seed_trajectories.csv | 50 | Five complete CartPole–PPO trajectories with initialization and final held values |
| controller_costs.csv | 70 | Unique retained controller costs |
| tpe_costs.csv | 12 | Shared task–algorithm TPE study costs |
| cost_summary_deduplicated.json | 1 ledger | Deduplicated retained-stage totals and separately disclosed exploratory costs |
| exploratory_not_core.csv | 42 | Additional completed exploratory deployments, excluded from primary comparisons |

The `source_data` directory was copied without changing the experimental files from the author-held `2026-09-ver/revision_2026-09-14_results/source_data` directory on 2026-10-11. The current audit checks file consistency; it is not a new training run. CartPole uses a 1000-step cap; bsuite Memory /0 has length 1. No primary comparison rejects at 5% after Holm adjustment. Ties are not evidence of equivalence.

SHA256SUMS.txt identifies every enclosed file except the manifest itself. The original code snapshot is in the separate reference_code.zip attachment; its source hash matches every formal seed record. Trained model weights are not included. The code snapshot's older full experiment queue is not a claim that every planned run was completed; the formal scope is exactly the 265-run list here.

Access: this archive is supplied locally with the revision. Journal-system upload and reviewer/editor download access must be confirmed separately. No current public repository accessibility claim is made by this README.
