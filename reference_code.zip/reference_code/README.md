# AMRL reviewer experiment implementation

This repository now runs **new, auditable experiments**. The uploaded snapshot contained no historical results or checkpoints and did not actually optimize its meta-controller. Consequently, this code cannot recover or certify the numerical results in the existing manuscript.

The reference backend is Stable-Baselines3 PPO/A2C/DQN on CPU. A separate recurrent Gaussian PPO controller regulates learning rate, discount factor, and epsilon/entropy coefficient. See [the audit and protocol](docs/IMPLEMENTATION_AND_PROTOCOL.md) and [the Chinese handoff](docs/修订说明.md).

## Install

Use Python 3.11–3.13, preferably in a dedicated environment:

```sh
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pytest tests -q
```

The local project environment created during this revision inherits the host's installed PyTorch; `requirements-local-freeze.txt` records its resolved packages. It does not modify the global Python installation.

## Run

Run commands **from this repository directory**:

```sh
# Five seeds, all main / ablation / transfer conditions, short budgets.
python -m experiments.run --config configs/review_pilot.json --output results/reviewer_pilot

# Inspect the complete longer-budget job matrix without training.
python -m experiments.run --config configs/review_full.json --output results/reviewer_full --plan-only

# Execute that matrix. This is substantially more expensive than the pilot.
python -m experiments.run --config configs/review_full.json --output results/reviewer_full

# Rebuild reports, including coverage of partially completed runs.
python -m experiments.summarize results/reviewer_pilot
```

A run resumes at completed tuning stages, controllers and evaluation jobs. A partially trained controller is rerun, not silently continued with an incomplete optimizer state. The runner refuses to reuse an output directory if its configuration or source fingerprint changes. Failed jobs are recorded separately and are never converted into scores.

`review_full.json` is a **new declared 100k-step protocol**, not proof of matching the unknown historical training details. `review_pilot.json` is an implementation pilot and must not be presented as full-budget paper evidence.

## Outputs

- `manifest.json`: exact protocol, source fingerprint and expected job matrix.
- `seed_results.csv`: one row per independent training seed and condition; no rounding to two decimals.
- `descriptive_summary.csv`, `paired_statistics.json`: seed-level summaries, paired confidence intervals, exact sign-flip tests, and primary-family Holm correction when all twelve contrasts exist.
- `coverage.json`: expected/completed/missing rows; a full table is never claimed from an incomplete set.
- `controllers/<role>_<seed>/controller.pt`: trained weights, architecture, bounds, normalization statistics, training tasks and algorithms.
- `controllers/<role>_<seed>/cost.json`: actual total meta-training time, inner training time, outer optimizer time, interactions, parameter change, hardware, and per-episode traces.
- `runs/*/base_model.zip`, `run.json`, `result.json`: trained checkpoint, evaluation episodes, seed, applied controller actions, costs and provenance.
- `tuning/*.json`: real TPE trial training and held-out tuning-seed evaluations; selected initialization is shared by all methods in that algorithm/task pair.
- `cost_summary.json`: unique measured stages, avoiding double counting reused controllers or initializations.
- `REPORT.md`: generated results with explicit scope and completeness.

Evaluation episodes are repeated measurements of a single trained model; they are **not** additional independent training seeds. Both meta-training and deployment are replicated across the five listed seeds. Controller evaluation is deterministic with frozen weights and frozen normalization.

## Important scope differences

`bsuite/memory_len/0` and `bsuite/catch/0` are explicit task instances. The exported metric is deterministic raw episode return, not the manuscript's normalized bsuite capability scores or a full bsuite sweep. The current experiment matrix does not implement PBT. No fixed overhead percentage or claim of outperforming the original paper is embedded in the code.

TPE uses fixed-budget trained trials without pruning. Gradient features are measured **after** SB3 gradient clipping; loss features use its last training-update aggregate. These choices are documented so they cannot be mistaken for verified historical implementation details.

The original snapshot is backed up beside this repository as `AMRL-Meta-Net-main_backup_2026-09-12/`.
